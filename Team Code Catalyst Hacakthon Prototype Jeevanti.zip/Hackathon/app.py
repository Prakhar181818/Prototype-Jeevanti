from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from google.oauth2 import service_account
import os


app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a strong secret key

# In-memory user storage for demonstration (replace with a database in production)
users = {}

# Load your service account credentials (optional, for integrating with Google APIs)
SERVICE_ACCOUNT_FILE = 'json.json'  # Update this path
credentials = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return "Invalid credentials"
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username not in users:
            users[username] = password
            return redirect(url_for('login'))
        else:
            return "User already exists"
    return render_template('register.html')

@app.route('/index')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/chatbot')
def chatbot():
    # Redirect to the Streamlit app for the chatbot
    return redirect("http://localhost:8501")  # Assuming Streamlit runs on port 8501

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    print(f"Received message: {user_message}")  # Debug print
    bot_response = f"Bot: You said '{user_message}'"
    print(f"Sending response: {bot_response}")  # Debug print
    return jsonify({'response': bot_response})

@app.route('/upload_image', methods=['POST'])
def upload_image():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400

    image = request.files['image']
    # Here you can process the image (e.g., saving it or analyzing it)
    # For this example, we'll just return a success message
    return jsonify({'message': 'Image received successfully'})

@app.route('/call_ambulance', methods=['POST'])
def call_ambulance():
    # Logic to call the ambulance service can be implemented here
    return jsonify({'message': 'Ambulance is on the way!'})

if __name__ == '__main__':
    app.run(debug=True)
