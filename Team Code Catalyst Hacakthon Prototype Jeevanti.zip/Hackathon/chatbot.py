from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/chatbot', methods=['GET'])
def chatbot():
    return render_template('chatbot.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    # Here you can add logic to process the user message and generate a response
    # For simplicity, we'll echo the user's message as the bot's response
    bot_response = f"Bot: You said '{user_message}'"
    return jsonify({'response': bot_response})

@app.route('/upload_image', methods=['POST'])
def upload_image():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400

    image = request.files['image']
    # Here you can process the image (e.g., saving it or analyzing it)
    # For this example, we'll just return a success message
    return jsonify({'message': 'Image received successfully'})

if __name__ == '__main__':
    app.run(debug=True)
